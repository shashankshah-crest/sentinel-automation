"""Logging configuration for Vectra XDR Data Connector."""
import logging
import sys

# Configure the Azure logger
applogger = logging.getLogger("azure")
applogger.setLevel(logging.INFO)

# Create console handler if not already present
if not applogger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    applogger.addHandler(handler)


# Sensitive fields to sanitize in logs
SENSITIVE_FIELDS = [
    "password",
    "token",
    "api_key",
    "secret",
    "authorization",
    "client_secret",
    "workspace_key",
]


def sanitize_log_message(message: str) -> str:
    """
    Sanitize sensitive information from log messages.

    Args:
        message: The log message to sanitize.

    Returns:
        Sanitized log message with sensitive data masked.
    """
    sanitized = message
    for field in SENSITIVE_FIELDS:
        if field.lower() in sanitized.lower():
            # Simple masking - in production, use regex for better accuracy
            sanitized = sanitized.replace(field, "[REDACTED]")
    return sanitized
