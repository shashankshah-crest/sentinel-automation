"""State management using Azure Table Storage for checkpoints."""
import inspect
import json
from typing import Any, Optional, Dict
from azure.data.tables import TableServiceClient, TableClient
from azure.core.exceptions import ResourceNotFoundError, ResourceExistsError
from SharedCode.logger import applogger
from SharedCode.consts import LOGS_STARTS_WITH, AZURE_STORAGE_CONNECTION_STRING, STATE_PARTITION_KEY
from SharedCode.exceptions import CheckpointException


class StateManager:
    """Manage checkpoint state using Azure Table Storage."""

    def __init__(self, connection_string: str = None, table_name: str = "Checkpoints", partition_key: str = None):
        """
        Initialize the StateManager.

        Args:
            connection_string: Azure Storage connection string (optional, uses env var if not provided).
            table_name: Name of the table to store checkpoints.
            partition_key: Partition key for table storage (optional, uses default from config).
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} StateManager:"
        __method_name = inspect.currentframe().f_code.co_name

        self.connection_string = connection_string or AZURE_STORAGE_CONNECTION_STRING
        self.table_name = table_name
        self.partition_key = partition_key or STATE_PARTITION_KEY

        try:
            self.table_service = TableServiceClient.from_connection_string(self.connection_string)
            self._ensure_table_exists()
            self.table_client: TableClient = self.table_service.get_table_client(self.table_name)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) StateManager initialized.")
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to initialize: {err}")
            raise CheckpointException(f"Failed to initialize StateManager: {err}") from err

    def _ensure_table_exists(self) -> None:
        """Ensure the checkpoint table exists, create if not."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.table_service.create_table(self.table_name)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Created table {self.table_name}.")
        except ResourceExistsError:
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) Table {self.table_name} already exists.")

    def get_state(self, row_key: str) -> Optional[Any]:
        """
        Retrieve a specific state value.

        Args:
            row_key: The row key identifying the state field (e.g., 'access_token_expiry').

        Returns:
            The state value, or None if not found.

        Raises:
            CheckpointException: If retrieval fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            entity = self.table_client.get_entity(
                partition_key=self.partition_key,
                row_key=row_key,
            )
            value = entity.get("Value")
            if value is not None:
                # Try to parse as JSON, otherwise return as-is
                try:
                    return json.loads(value)
                except (json.JSONDecodeError, TypeError):
                    return value
            return None
        except ResourceNotFoundError:
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) State '{row_key}' not found.")
            return None
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to get state '{row_key}': {err}")
            raise CheckpointException(f"Failed to retrieve state '{row_key}': {err}") from err

    def save_state(self, row_key: str, value: Any) -> None:
        """
        Save a specific state value.

        Args:
            row_key: The row key identifying the state field (e.g., 'access_token_expiry').
            value: The value to save (will be JSON serialized if dict/list).

        Raises:
            CheckpointException: If save fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            # Serialize complex types to JSON
            if isinstance(value, (dict, list)):
                stored_value = json.dumps(value)
            else:
                stored_value = str(value) if value is not None else None

            entity = {
                "PartitionKey": self.partition_key,
                "RowKey": row_key,
                "Value": stored_value,
            }
            self.table_client.upsert_entity(entity)
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) State '{row_key}' saved.")
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to save state '{row_key}': {err}")
            raise CheckpointException(f"Failed to save state '{row_key}': {err}") from err

    def delete_state(self, row_key: str) -> None:
        """
        Delete a specific state value.

        Args:
            row_key: The row key identifying the state field to delete.

        Raises:
            CheckpointException: If deletion fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.table_client.delete_entity(
                partition_key=self.partition_key,
                row_key=row_key,
            )
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) State '{row_key}' deleted.")
        except ResourceNotFoundError:
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) State '{row_key}' not found to delete.")
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to delete state '{row_key}': {err}")
            raise CheckpointException(f"Failed to delete state '{row_key}': {err}") from err

    def get_all_states(self) -> Dict[str, Any]:
        """
        Retrieve all state values for the partition.

        Returns:
            Dictionary mapping row keys to their values.

        Raises:
            CheckpointException: If retrieval fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            query_filter = f"PartitionKey eq '{self.partition_key}'"
            entities = self.table_client.query_entities(query_filter=query_filter)
            
            states = {}
            for entity in entities:
                row_key = entity.get("RowKey")
                value = entity.get("Value")
                if row_key and value is not None:
                    # Try to parse as JSON
                    try:
                        states[row_key] = json.loads(value)
                    except (json.JSONDecodeError, TypeError):
                        states[row_key] = value
            
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) Retrieved {len(states)} states.")
            return states
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to get all states: {err}")
            raise CheckpointException(f"Failed to retrieve all states: {err}") from err
