"""Constants and environment variables for Vectra XDR Data Connector."""

import os

# Logging prefix
LOGS_STARTS_WITH = "VectraXDR"

# Timeout settings (9.5 minutes to allow graceful shutdown before 10 min limit)
MAX_EXECUTION_TIME = 570

# Function Names
DETECTIONS_NAME = "Detections"

# Retry status codes
RETRY_STATUS_CODES = [429, 500, 503, 401]

# Data limits
MAX_PAYLOAD_SIZE_MB = 25  # 25MB buffer (limit is 30MB)
MAX_CELL_SIZE_KB = 25  # 25KB buffer (limit is 30KB)
MAX_TABLE_NAME_LENGTH = 52

# Schedule (cron expression)
SCHEDULE = os.environ.get("Schedule", "0 */5 * * * *")

# Vectra XDR API Configuration
VECTRA_API_BASE_URL = os.environ.get("VectraAPIBaseURL", "")
VECTRA_API_CLIENT_ID = os.environ.get("VectraAPIClientId", "")
VECTRA_API_CLIENT_SECRET = os.environ.get("VectraAPIClientSecret", "")

# Azure Configuration
AZURE_CLIENT_ID = os.environ.get("AzureClientId", "")
AZURE_CLIENT_SECRET = os.environ.get("AzureClientSecret", "")
AZURE_TENANT_ID = os.environ.get("AzureTenantId", "")
SCOPE = os.environ.get("Scope", "https://monitor.azure.com/.default")
FUNCTION_APP_NAME = os.environ.get("Function_App_Name")
RESOURCE_GROUP = os.environ.get("Azure_Resource_Group_Name")
SUBSCRIPTION_ID = os.environ.get("Azure_Subscription_Id")

# Log Analytics / Sentinel Configuration
WORKSPACE_ID = os.environ.get("WorkspaceId", "")
DCE_ENDPOINT = os.environ.get("DataCollectionEndpoint", "")
DCR_RULE_ID = os.environ.get("DataCollectionRuleId", "")
DETECTIONS_TABLE_NAME = os.environ.get("DetectionsTableName", "VectraXDRDetections_CL")

# Azure Storage Configuration (for checkpoints)
AZURE_STORAGE_CONNECTION_STRING = os.environ.get("AzureWebJobsStorage", "")

# Azure Key Vault Configuration
KEY_VAULT_NAME = os.environ.get("KeyVaultName", "")

# Key Vault Secret Names for OAuth Tokens
KV_ACCESS_TOKEN_SECRET = "detection-access-token"
KV_REFRESH_TOKEN_SECRET = "detection-refresh-token"

# State Manager Keys for Checkpoints
STATE_ACCESS_TOKEN_EXPIRY = "access_token_expiry"
STATE_REFRESH_TOKEN_EXPIRY = "refresh_token_expiry"
STATE_NEXT_CHECKPOINT = "next_checkpoint"
STATE_PARTITION_KEY = "detections"
STATE_DISABLE_FUNCTION = "disable_function"
STATE_DISABLE_FUNCTION_COUNT = "status_code_count"

# Detections API Configuration
DETECTIONS_EVENTS_ENDPOINT = "/api/v3.5/events/detections"
DETECTIONS_DETAILS_ENDPOINT = "/api/v3.5/detections"
DEFAULT_PAGE_SIZE = 100
DETECTIONS_RESPONSE_SIZE = os.environ.get("DetectionsResponseSize", "regular")
EXCLUDE_GROUPED_DETAILS = (
    os.environ.get("ExcludeGroupedDetails", "False").lower() == "true"
)

# Fields to merge from detection details based on entity type
HOST_MERGE_FIELDS = [
    "is_targeting_key_asset",
    "tags",
    "src_host",
    "normal_domains",
    "summary",
    "grouped_details",
]
ACCOUNT_MERGE_FIELDS = ["tags"]

# Azure API URLs
AZURE_AUTHENTICATION_URL = (
    "https://login.microsoftonline.us/{}/oauth2/v2.0/token"
    if ".us" in SCOPE.lower()
    else "https://login.microsoftonline.com/{}/oauth2/v2.0/token"
)
AZURE_AUTHENTICATION_SCOPE = (
    "https://management.usgovcloudapi.net/.default"
    if ".us" in SCOPE.lower()
    else "https://management.azure.com/.default"
)
DISABLE_FUNCTION_APP_URL = (
    (
        "https://management.usgovcloudapi.net/subscriptions/{}/resourceGroups/{}/providers/"
        "Microsoft.Web/sites/{}/stop?api-version=2023-01-01"
    )
    if ".us" in SCOPE.lower()
    else (
        "https://management.azure.com/subscriptions/{}/resourceGroups/{}/providers/"
        "Microsoft.Web/sites/{}/stop?api-version=2023-01-01"
    )
)
